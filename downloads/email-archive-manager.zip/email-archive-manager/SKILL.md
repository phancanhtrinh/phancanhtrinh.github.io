---
name: email-archive-manager
description: Build, migrate, update, search, verify, and report on a private local email archive across Outlook, Gmail, EML, and PST sources, including attachments and duplicate reconciliation. Use when a user wants email retained for future questions or moved to another computer/account. Do not use for sending, deleting, or replying to email.
---

# Email Archive Manager

Create a durable local knowledge archive whose results remain traceable to the original mailbox or file. Treat mailbox access and message contents as private data.

## Route the task

1. Inventory the target computer and requested accounts without changing them.
2. Read [references/setup-and-sources.md](references/setup-and-sources.md) for the detected source type.
3. For a new archive, run `scripts/email_archive.py init --root <archive-root>`.
4. Import EML directly with `scripts/email_archive.py import-eml`. For live Outlook, Gmail, or PST, follow the source adapter guidance and normalize into the archive contract.
5. Read [references/archive-contract.md](references/archive-contract.md) before implementing or modifying an importer, deduplication, attachment handling, or migration.
6. Verify before reporting completion: `scripts/email_archive.py verify --root <archive-root>`.
7. For summaries, HTML indexes, or recurring updates, read [references/reporting-and-automation.md](references/reporting-and-automation.md).

## Required behavior

- Obtain authorization before first access to each mailbox/account and before enabling a recurring job. Account access never authorizes sending, deleting, moving, labeling, or marking mail read.
- Never store passwords, OAuth tokens, session cookies, OTPs, access keys, or private signed URLs in reports. Use the platform credential store or an existing authenticated session.
- Preserve source provenance. A duplicate may share one canonical record or blob, but every source occurrence must remain traceable.
- Store attachments content-addressed by SHA-256 and also provide human-readable views with original filenames and normal extensions. Determine type from file signature first and filename/MIME second.
- Use exact duplicate links for Message-ID or byte/content hashes. Label subject/date heuristics as probable; never silently merge ambiguous mail.
- Snapshot live SQLite mail stores with the SQLite backup API so WAL content is included. Do not copy only the main database file.
- Keep the archive private: directories `0700`, database and attachment files `0600` where supported. Warn when the chosen root is cloud-synchronized or institution-managed.
- Reconcile old PST/EML exports against current mailboxes rather than importing them as an unrelated corpus.
- Report gaps explicitly: missing bodies, unavailable attachments, parser warnings, unsupported OST files, inaccessible cloud links, or messages that exist only as previews.
- Do not claim completion until database integrity, source counts, attachment existence/hash checks, and search indexing pass.

## Portable helper

`scripts/email_archive.py` is a dependency-free Python 3 helper for initializing an archive, importing EML trees, searching, verifying hashes/integrity, and creating a local HTML report. It is the baseline path on a new computer; source-specific adapters may add records to the same schema.

Keep automatic skill selection enabled. When the user explicitly says `$email-archive-manager`, apply this workflow even if the archive is not yet initialized.
