# Archive contract

An importer may extend the schema, but it must preserve these invariants.

## Canonical records

Each canonical email stores source-independent identity, account/folder, participants, timestamps, body status, flags, and archived-at time. Each source occurrence stores source type, record ID, path/folder, import run, and optional raw hash. Never discard provenance merely because another source contains the same message.

## Attachments

- Calculate SHA-256 over the exact bytes.
- Store one blob at `attachments/blobs/<first-two-hash-chars>/<sha256>`.
- Store original filename, detected type, MIME, byte size, disposition/content ID, source message relationship, and extraction status in SQLite.
- Human-readable folders may use hard links when supported. Otherwise use symlinks only when the sync platform preserves them; copies are the last resort.
- Sanitize path separators and reserved names, but retain the original filename in metadata.
- Inline signature graphics count as relationships but should be distinguishable from substantive documents.

## Duplicate confidence

- **Exact:** identical normalized Message-ID, raw message hash, or deterministic canonical content hash.
- **Probable:** unique normalized-subject plus exact-timestamp match with compatible participants, or similarly strong evidence.
- **Related only:** same project/topic or quoted earlier message. Do not merge.

One source record must never be attached to multiple canonical messages. One attachment blob may have many relationships.

## Minimum verification gates

- `PRAGMA integrity_check` returns `ok` and foreign-key checks return no rows.
- Search-index row count matches canonical email count.
- Every attachment resolves beneath the archive root, exists, and matches stored size and SHA-256.
- No unregistered blobs remain except documented quarantine files.
- Every source reports imported/recovered/failed status and counts.
- Every message flagged with attachments is linked to saved files or explicitly marked incomplete.
- Permissions are private where POSIX modes are supported.

Use a transaction per source batch. If a transaction fails after writing blobs, quarantine unreferenced files rather than deleting them silently.
