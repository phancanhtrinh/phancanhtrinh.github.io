# Reporting and automation

## Reports

- Provide account/folder/date coverage and import-quality warnings.
- For a contact or project, include deduplicated counts, timeline, threads, action items, attachment inventory, and external resource locations.
- HTML reports should be self-contained, searchable, printable, and escape all email content before embedding it.
- Link human-readable local attachment paths and label the application that normally opens each type.
- Do not embed passwords, OTPs, access keys, session tokens, or private signed URLs. A portal home link plus shared-folder name is usually safer.

## Incremental updates

- Use a small overlap window, normally 8 days for a weekly job, to catch delayed synchronization and modified messages.
- Upsert by source record ID; reconcile exact identities after import.
- Re-download an attachment only when its source association is new or stored bytes are missing.
- Save a dated digest and machine-readable run record containing counts, warnings, and verification status.

## Scheduling

Create a Codex automation only when the user requests recurring updates. Its prompt should specify archive root, accounts/sources, interval/timezone, attachment requirements, exclusions, verification, and failure notification behavior.

An automation does not broaden account permissions. If authentication expires, report failure and ask the user to reconnect; never extract or reuse browser/session credentials.
