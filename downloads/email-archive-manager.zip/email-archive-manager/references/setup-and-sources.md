# Setup and source adapters

Read only the section matching the target source. Prefer a native connector or documented API when available; use browser control only when a connector cannot perform the required read/export operation.

## Initial inventory

- Confirm the archive root, accounts in scope, desired historical range, attachment policy, and whether the root is cloud-synchronized.
- Record source type, account address, source path or API identity, size, earliest/latest date if discoverable, and a stable source fingerprint.
- Do not begin a bulk download or GUI account authorization until the user approves that account and destination.

## EML directories

Use the bundled importer:

```bash
python3 scripts/email_archive.py import-eml --root "/path/to/archive" --account "name@example.com" "/path/to/eml-export"
```

The importer recursively processes `.eml`, extracts readable bodies and attachments, preserves source paths, and deduplicates exact identities.

## Outlook for Mac

1. Discover profiles under `~/Library/Group Containers/UBF8T346G9.Office/Outlook/Outlook 15 Profiles/` rather than assuming `Main Profile`.
2. Identify `Outlook.sqlite`, enumerate accounts/folders read-only, and show the user what will be archived.
3. Create a consistent snapshot with Python `sqlite3.Connection.backup`; the live database may use WAL.
4. Import metadata/previews from the snapshot. Use Outlook AppleScript only for bodies and attachments that are not available in the database files.
5. Match AppleScript message IDs to the imported source record IDs. Save every attachment, then hash and register it; a `has_attachments` flag without attachment rows is an incomplete import.
6. Exclude Deleted/Junk/Drafts only if the user requests that policy. Record exclusions in the run manifest.

AppleScript requires macOS Automation permission and may prompt the user. Never use it to send or modify mail.

## Outlook for Windows

- Prefer an explicit PST export or EML export. OST is a cache and may be incomplete or encrypted; do not promise direct OST recovery.
- If Outlook automation is available, use read-only export and preserve EntryID/Internet Message-ID as provenance.
- Obtain confirmation before launching Outlook or performing a bulk export.

## PST files

- Hash each PST before import and treat the original as immutable.
- Prefer two independent parsers for damaged or legacy PSTs when practical, for example `libpff/pffexport` and `libpst/readpst`.
- Import primary results, then use the secondary EML output to recover missing bodies/attachments.
- Record parser versions, warnings, message counts, and attachment counts per source.
- Keep unmatched recovery messages as separate provenance records. Add probable duplicate links only when evidence is unique and strong.
- Parser binaries are platform-specific; build or install them on the target computer rather than copying a binary from another architecture.

## Gmail or Google Workspace

Preferred order:

1. Installed Gmail connector/API with read-only scope.
2. Google Takeout MBOX export converted to EML.
3. An already authenticated browser session for focused or incremental retrieval when bulk export is unavailable.

Do not store browser cookies or OAuth tokens in the archive. Preserve Gmail message/thread IDs and labels. Download original attachments; do not treat Google Drive links as attachments. Record cloud links separately with access requirements and expiration when known.

## Migration to another computer

- Copy the archive root plus the skill folder. Do not copy mailbox credentials.
- On the target, run `verify` before connecting a new account.
- Add the new source/account as a new provenance origin, then reconcile exact duplicates.
- If the archive lives in OneDrive, Dropbox, or another sync folder, wait for full local hydration before hash verification.
