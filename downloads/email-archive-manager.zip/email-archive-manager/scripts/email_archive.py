#!/usr/bin/env python3
"""Portable private email archive helper (Python standard library only)."""

from __future__ import annotations

import argparse
import datetime as dt
import email
import hashlib
import html
import json
import mimetypes
import os
import re
import shutil
import sqlite3
from email import policy
from email.header import decode_header, make_header
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from pathlib import Path


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS emails (
  id INTEGER PRIMARY KEY,
  canonical_key TEXT NOT NULL UNIQUE,
  message_id TEXT,
  account TEXT, folder TEXT, subject TEXT, sender TEXT,
  recipients_to TEXT, recipients_cc TEXT,
  sent_at INTEGER, body TEXT, body_status TEXT NOT NULL,
  has_attachments INTEGER NOT NULL DEFAULT 0,
  archived_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS source_records (
  id INTEGER PRIMARY KEY,
  email_id INTEGER NOT NULL REFERENCES emails(id) ON DELETE CASCADE,
  source_type TEXT NOT NULL, source_name TEXT NOT NULL,
  source_record_id TEXT NOT NULL, source_path TEXT,
  raw_sha256 TEXT, imported_at TEXT NOT NULL,
  UNIQUE(source_type, source_name, source_record_id)
);
CREATE TABLE IF NOT EXISTS attachment_blobs (
  sha256 TEXT PRIMARY KEY, byte_size INTEGER NOT NULL,
  relative_path TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attachments (
  id INTEGER PRIMARY KEY,
  email_id INTEGER NOT NULL REFERENCES emails(id) ON DELETE CASCADE,
  source_record_id INTEGER REFERENCES source_records(id) ON DELETE SET NULL,
  ordinal INTEGER NOT NULL, original_name TEXT, safe_name TEXT NOT NULL,
  mime_type TEXT, detected_type TEXT, opens_with TEXT,
  byte_size INTEGER NOT NULL, sha256 TEXT NOT NULL REFERENCES attachment_blobs(sha256),
  relative_path TEXT NOT NULL, disposition TEXT,
  UNIQUE(source_record_id, ordinal, sha256)
);
CREATE VIRTUAL TABLE IF NOT EXISTS emails_fts USING fts5(
  subject, sender, recipients_to, recipients_cc, body,
  content='emails', content_rowid='id'
);
CREATE TRIGGER IF NOT EXISTS emails_ai AFTER INSERT ON emails BEGIN
  INSERT INTO emails_fts(rowid,subject,sender,recipients_to,recipients_cc,body)
  VALUES(new.id,new.subject,new.sender,new.recipients_to,new.recipients_cc,new.body);
END;
CREATE TRIGGER IF NOT EXISTS emails_ad AFTER DELETE ON emails BEGIN
  INSERT INTO emails_fts(emails_fts,rowid,subject,sender,recipients_to,recipients_cc,body)
  VALUES('delete',old.id,old.subject,old.sender,old.recipients_to,old.recipients_cc,old.body);
END;
"""


class TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def decode(value: str | None) -> str:
    if not value:
        return ""
    try:
        return str(make_header(decode_header(value)))
    except (LookupError, UnicodeError):
        return value


def safe_name(value: str, fallback: str = "attachment", limit: int = 140) -> str:
    value = re.sub(r"[\\/:*?\"<>|\x00-\x1f]+", "_", value).strip(" .")
    return (value or fallback)[:limit]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def archive_paths(root: Path) -> tuple[Path, Path]:
    return root / "archive" / "email_archive.sqlite", root / "attachments"


def connect(root: Path) -> sqlite3.Connection:
    database, _ = archive_paths(root)
    if not database.exists():
        raise SystemExit(f"Archive not initialized: {database}")
    db = sqlite3.connect(database)
    db.execute("PRAGMA foreign_keys=ON")
    db.row_factory = sqlite3.Row
    return db


def make_private(path: Path, directory: bool = False) -> None:
    try:
        os.chmod(path, 0o700 if directory else 0o600)
    except OSError:
        pass


def command_init(args: argparse.Namespace) -> None:
    root = Path(args.root).expanduser().resolve()
    database, attachments = archive_paths(root)
    for directory in (root, database.parent, attachments / "blobs", attachments / "by-account", root / "reports", root / "digests"):
        directory.mkdir(parents=True, exist_ok=True)
        make_private(directory, True)
    with sqlite3.connect(database) as db:
        db.executescript(SCHEMA)
    make_private(database)
    config = root / "archive_config.json"
    if not config.exists():
        config.write_text(json.dumps({"version": 1, "created_at": dt.datetime.now().astimezone().isoformat(), "sources": []}, indent=2) + "\n", encoding="utf-8")
        make_private(config)
    print(f"Initialized private email archive at {root}")


def message_body(message: email.message.EmailMessage) -> str:
    plain: list[str] = []
    rich: list[str] = []
    for part in message.walk():
        if part.is_multipart() or part.get_content_disposition() == "attachment":
            continue
        content_type = part.get_content_type()
        if content_type not in ("text/plain", "text/html"):
            continue
        try:
            content = part.get_content()
        except (LookupError, UnicodeError):
            payload = part.get_payload(decode=True) or b""
            content = payload.decode(part.get_content_charset() or "utf-8", errors="replace")
        if content_type == "text/plain":
            plain.append(str(content))
        else:
            parser = TextExtractor()
            parser.feed(str(content))
            rich.append(" ".join(parser.parts))
    body = "\n".join(plain or rich)
    return re.sub(r"[ \t]+", " ", body).strip()


def epoch_from_message(message: email.message.EmailMessage) -> int | None:
    try:
        value = parsedate_to_datetime(str(message.get("Date", "")))
        if value.tzinfo is None:
            value = value.replace(tzinfo=dt.timezone.utc)
        return int(value.timestamp())
    except (TypeError, ValueError, OverflowError):
        return None


def identify(data: bytes, filename: str, mime_type: str) -> tuple[str, str]:
    extension = Path(filename).suffix.lower()
    if data.startswith(b"%PDF-"):
        return "PDF document", "Preview or Adobe Acrobat"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "PNG image", "Preview"
    if data.startswith(b"\xff\xd8\xff"):
        return "JPEG image", "Preview"
    mapping = {
        ".doc": ("Microsoft Word document", "Microsoft Word"), ".docx": ("Microsoft Word document", "Microsoft Word"),
        ".xls": ("Microsoft Excel workbook", "Microsoft Excel"), ".xlsx": ("Microsoft Excel workbook", "Microsoft Excel"),
        ".csv": ("Comma-separated data", "Microsoft Excel"), ".ppt": ("Microsoft PowerPoint presentation", "Microsoft PowerPoint"),
        ".pptx": ("Microsoft PowerPoint presentation", "Microsoft PowerPoint"), ".pdf": ("PDF document", "Preview or Adobe Acrobat"),
        ".pzfx": ("GraphPad Prism data file", "GraphPad Prism"), ".r": ("R source-code script", "RStudio"),
        ".gb": ("GenBank sequence file", "SnapGene, Benchling, or ApE"), ".eml": ("Email message", "Outlook or Mail"),
        ".zip": ("ZIP archive", "Archive Utility"), ".txt": ("Text document", "TextEdit"),
    }
    if extension in mapping:
        return mapping[extension]
    if mime_type.startswith("image/"):
        return "Image", "Preview"
    if mime_type.startswith("text/"):
        return "Text document", "TextEdit"
    return "Other file", "Finder (choose an application)"


def store_attachment(root: Path, db: sqlite3.Connection, email_id: int, source_id: int, ordinal: int, filename: str, mime_type: str, disposition: str, data: bytes, sent_at: int | None, account: str) -> None:
    digest = sha256_bytes(data)
    relative = Path("attachments") / "blobs" / digest[:2] / digest
    blob = root / relative
    blob.parent.mkdir(parents=True, exist_ok=True)
    make_private(blob.parent, True)
    if not blob.exists():
        blob.write_bytes(data)
    make_private(blob)
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    db.execute("INSERT OR IGNORE INTO attachment_blobs VALUES (?,?,?,?)", (digest, len(data), str(relative), now))
    filename = filename or f"attachment-{ordinal}"
    safe = safe_name(filename)
    detected, software = identify(data[:64], filename, mime_type)
    db.execute(
        """INSERT OR IGNORE INTO attachments
           (email_id,source_record_id,ordinal,original_name,safe_name,mime_type,detected_type,opens_with,byte_size,sha256,relative_path,disposition)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (email_id, source_id, ordinal, filename, safe, mime_type, detected, software, len(data), digest, str(relative), disposition),
    )
    date = dt.datetime.fromtimestamp(sent_at or 0, dt.timezone.utc).astimezone() if sent_at else dt.datetime.now().astimezone()
    view_dir = root / "attachments" / "by-account" / safe_name(account, "unknown-account") / str(date.year) / f"{date.date()}_{email_id}"
    view_dir.mkdir(parents=True, exist_ok=True)
    make_private(view_dir, True)
    view = view_dir / f"{ordinal:02d}_{safe}"
    if not view.exists():
        try:
            os.link(blob, view)
        except OSError:
            try:
                view.symlink_to(blob)
            except OSError:
                shutil.copy2(blob, view)
    make_private(view)


def command_import_eml(args: argparse.Namespace) -> None:
    root = Path(args.root).expanduser().resolve()
    source_root = Path(args.path).expanduser().resolve()
    source_name = args.source_name or str(source_root)
    files = [source_root] if source_root.is_file() else sorted(source_root.rglob("*.eml"))
    imported = duplicate = failed = 0
    with connect(root) as db:
        db.execute("BEGIN IMMEDIATE")
        for path in files:
            try:
                raw = path.read_bytes()
                raw_hash = sha256_bytes(raw)
                message = email.message_from_bytes(raw, policy=policy.default)
                message_id = str(message.get("Message-ID", "")).strip().lower()
                subject, sender = decode(message.get("Subject")), decode(message.get("From"))
                recipients_to, recipients_cc = decode(message.get("To")), decode(message.get("Cc"))
                body, sent_at = message_body(message), epoch_from_message(message)
                canonical_material = "\x1f".join([subject.lower(), sender.lower(), recipients_to.lower(), str(sent_at or ""), body])
                canonical_key = f"mid:{message_id}" if message_id else f"content:{sha256_bytes(canonical_material.encode())}"
                existing = db.execute("SELECT id FROM emails WHERE canonical_key=?", (canonical_key,)).fetchone()
                if existing:
                    email_id, duplicate = existing[0], duplicate + 1
                else:
                    attachment_parts = [p for p in message.walk() if p.get_filename() or p.get_content_disposition() == "attachment"]
                    email_id = db.execute(
                        """INSERT INTO emails(canonical_key,message_id,account,folder,subject,sender,recipients_to,recipients_cc,sent_at,body,body_status,has_attachments,archived_at)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (canonical_key, message_id, args.account, args.folder, subject, sender, recipients_to, recipients_cc, sent_at, body, "full_eml", int(bool(attachment_parts)), dt.datetime.now(dt.timezone.utc).isoformat()),
                    ).lastrowid
                source_record = str(path.relative_to(source_root)) if source_root.is_dir() else path.name
                source_cursor = db.execute(
                    """INSERT OR IGNORE INTO source_records(email_id,source_type,source_name,source_record_id,source_path,raw_sha256,imported_at)
                       VALUES (?,?,?,?,?,?,?)""",
                    (email_id, "eml", source_name, source_record, str(path), raw_hash, dt.datetime.now(dt.timezone.utc).isoformat()),
                )
                if source_cursor.rowcount:
                    source_id = source_cursor.lastrowid
                else:
                    source_id = db.execute("SELECT id FROM source_records WHERE source_type='eml' AND source_name=? AND source_record_id=?", (source_name, source_record)).fetchone()[0]
                for ordinal, part in enumerate((p for p in message.walk() if p.get_filename() or p.get_content_disposition() == "attachment"), 1):
                    data = part.get_payload(decode=True) or b""
                    store_attachment(root, db, email_id, source_id, ordinal, decode(part.get_filename()) or f"attachment-{ordinal}", part.get_content_type(), part.get_content_disposition() or "inline", data, sent_at, args.account)
                imported += 1
            except Exception as exc:
                failed += 1
                print(f"WARNING: {path}: {exc}")
        db.commit()
    print(f"Processed {imported} EML files; exact duplicates={duplicate}; failed={failed}")


def command_search(args: argparse.Namespace) -> None:
    root = Path(args.root).expanduser().resolve()
    with connect(root) as db:
        rows = db.execute(
            """SELECT e.*,snippet(emails_fts,4,'[',']',' … ',24) excerpt,
                      (SELECT count(*) FROM attachments a WHERE a.email_id=e.id) attachment_count
               FROM emails_fts JOIN emails e ON e.id=emails_fts.rowid
               WHERE emails_fts MATCH ? ORDER BY e.sent_at DESC LIMIT ?""",
            (args.query, args.limit),
        )
        for row in rows:
            stamp = dt.datetime.fromtimestamp(row["sent_at"], dt.timezone.utc).astimezone().isoformat(timespec="minutes") if row["sent_at"] else "unknown"
            print(f"{stamp} | {row['account']} | {row['subject']}\n  From: {row['sender']} | Attachments: {row['attachment_count']}\n  {row['excerpt']}")


def command_verify(args: argparse.Namespace) -> None:
    root = Path(args.root).expanduser().resolve()
    errors: list[str] = []
    with connect(root) as db:
        if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            errors.append("database integrity_check failed")
        if db.execute("PRAGMA foreign_key_check").fetchall():
            errors.append("foreign-key violations found")
        emails = db.execute("SELECT count(*) FROM emails").fetchone()[0]
        fts = db.execute("SELECT count(*) FROM emails_fts").fetchone()[0]
        if emails != fts:
            errors.append(f"FTS count {fts} != email count {emails}")
        for row in db.execute("SELECT * FROM attachment_blobs"):
            path = (root / row["relative_path"]).resolve()
            try:
                path.relative_to(root)
            except ValueError:
                errors.append(f"unsafe blob path: {path}")
                continue
            if not path.is_file():
                errors.append(f"missing blob: {path}")
            elif path.stat().st_size != row["byte_size"] or sha256_bytes(path.read_bytes()) != row["sha256"]:
                errors.append(f"blob hash/size mismatch: {path}")
        incomplete = db.execute("SELECT count(*) FROM emails e WHERE has_attachments=1 AND NOT EXISTS(SELECT 1 FROM attachments a WHERE a.email_id=e.id)").fetchone()[0]
        if incomplete:
            errors.append(f"{incomplete} messages flagged with attachments have no saved attachment rows")
        print(f"Messages: {emails}; attachment blobs: {db.execute('SELECT count(*) FROM attachment_blobs').fetchone()[0]}; incomplete attachment messages: {incomplete}")
    if errors:
        print(*[f"ERROR: {item}" for item in errors], sep="\n")
        raise SystemExit(1)
    print("Verification: PASS")


def command_report(args: argparse.Namespace) -> None:
    root = Path(args.root).expanduser().resolve()
    with connect(root) as db:
        total = db.execute("SELECT count(*) FROM emails").fetchone()[0]
        accounts = db.execute("SELECT account,count(*) n,min(sent_at) first,max(sent_at) last FROM emails GROUP BY account ORDER BY n DESC").fetchall()
        recent = db.execute("SELECT id,sent_at,account,subject,sender FROM emails ORDER BY sent_at DESC LIMIT ?", (args.limit,)).fetchall()
        attachment_count = db.execute("SELECT count(*) FROM attachments").fetchone()[0]
    account_rows = "".join(f"<tr><td>{html.escape(r['account'] or '')}</td><td>{r['n']}</td><td>{html.escape(str(r['first'] or ''))}</td><td>{html.escape(str(r['last'] or ''))}</td></tr>" for r in accounts)
    email_rows = "".join(f"<tr class='mail'><td>{html.escape(dt.datetime.fromtimestamp(r['sent_at'],dt.timezone.utc).astimezone().isoformat(timespec='minutes') if r['sent_at'] else 'unknown')}</td><td>{html.escape(r['account'] or '')}</td><td>{html.escape(r['subject'] or '')}</td><td>{html.escape(r['sender'] or '')}</td></tr>" for r in recent)
    document = f"""<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Email Archive Report</title><style>body{{font:15px/1.5 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;max-width:1100px;margin:40px auto;padding:0 20px;color:#20313d}}h1{{color:#174a68}}.stats{{display:flex;gap:15px}}.stats b{{font-size:28px;display:block}}.card{{padding:18px;border:1px solid #d7e1e7;border-radius:10px;background:#f8fbfc}}input{{width:100%;padding:12px;margin:18px 0}}table{{width:100%;border-collapse:collapse}}th,td{{padding:9px;border-bottom:1px solid #dde5ea;text-align:left}}</style></head><body><h1>Email Archive Report</h1><div class='stats'><div class='card'><b>{total}</b>messages</div><div class='card'><b>{attachment_count}</b>attachment relationships</div><div class='card'><b>{len(accounts)}</b>accounts</div></div><h2>Accounts</h2><table><tr><th>Account</th><th>Messages</th><th>First epoch</th><th>Last epoch</th></tr>{account_rows}</table><h2>Recent mail</h2><input id='q' placeholder='Filter recent mail'><table id='m'><tr><th>Date</th><th>Account</th><th>Subject</th><th>Sender</th></tr>{email_rows}</table><script>q.oninput=()=>document.querySelectorAll('.mail').forEach(r=>r.style.display=r.textContent.toLowerCase().includes(q.value.toLowerCase())?'':'none')</script></body></html>"""
    output = root / "reports" / "email-archive-report.html"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(document, encoding="utf-8")
    make_private(output)
    print(f"Wrote {output}")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    sub = result.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init"); init.add_argument("--root", required=True); init.set_defaults(func=command_init)
    imp = sub.add_parser("import-eml"); imp.add_argument("path"); imp.add_argument("--root", required=True); imp.add_argument("--account", required=True); imp.add_argument("--folder", default="Imported EML"); imp.add_argument("--source-name"); imp.set_defaults(func=command_import_eml)
    search = sub.add_parser("search"); search.add_argument("query"); search.add_argument("--root", required=True); search.add_argument("--limit", type=int, default=25); search.set_defaults(func=command_search)
    verify = sub.add_parser("verify"); verify.add_argument("--root", required=True); verify.set_defaults(func=command_verify)
    report = sub.add_parser("report"); report.add_argument("--root", required=True); report.add_argument("--limit", type=int, default=500); report.set_defaults(func=command_report)
    return result


if __name__ == "__main__":
    arguments = parser().parse_args()
    arguments.func(arguments)
